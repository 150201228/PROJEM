<?= $this->title = 'Modül çalışıyor.'; ?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Kou Osl Yii2 App</h1>

        <p class="lead">Örnek uygulamayı başarılı bir şekilde çalıştırdınız.</p>

        <p><a class="btn btn-lg btn-success" href="#">Modüller ve konfürgasyon!</a></p>
    </div>

</div>
