<?php

use yii\db\Migration;

/**
 * Class m200110_193838_adres_defteri
 */
class m200110_193838_adres_defteri extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('adres_defteri', [
            'kisi_id' => "int(20) unsigned NOT NULL AUTO_INCREMENT",
            'kisi_ad_soyad' => $this->string()->notNull(),
            'phone'=>$this->string()->notNull(),
            'is_use_whatsapp'=>$this->boolean(),
            "PRIMARY KEY (`kisi_id`)",
        ], 'ENGINE=InnoDB DEFAULT CHARSET=utf8');
        
        


    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('adres_defteri');

    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200110_193838_adres_defteri cannot be reverted.\n";

        return false;
    }
    */
}
