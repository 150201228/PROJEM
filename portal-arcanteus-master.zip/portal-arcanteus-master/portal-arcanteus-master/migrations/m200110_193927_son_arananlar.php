<?php

use yii\db\Migration;

/**
 * Class m200110_193927_son_arananlar
 */
class m200110_193927_son_arananlar extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('son_arananlar', [
            'arama_id'=>"int(20) unsigned NOT NULL AUTO_INCREMENT",
            'aranan_adi' => $this->string()->notNull(),
            'son_tarih' => $this->date()->notNull(),
            "PRIMARY KEY (`arama_id`)",
    
        ], 'ENGINE=InnoDB DEFAULT CHARSET=utf8');
        
        
       /*$this->addForeignKey(
        'fk-son_arananlar_aranan_adi',
        'son_arananlar',
        'aranan_adi',
        'adres_defteri',
        'kisi_id',
        'CASCADE'
    );*/

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('son_arananlar');
       /* $this->dropForeignKey(
            'fk-son_arananlar_aranan_adi',
            'son_arananlar'
        );*/
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200110_193927_son_arananlar cannot be reverted.\n";

        return false;
    }
    */
}
